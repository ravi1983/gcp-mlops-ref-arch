def perform_inference(request):
    return 'OK'